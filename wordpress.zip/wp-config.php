<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress-353038397f99' );

/** Database username */
define( 'DB_USER', 'wordpress-353038397f99' );

/** Database password */
define( 'DB_PASSWORD', '0qQAmV!cs(^-' );

/** Database hostname */
define( 'DB_HOST', 'sdb-82.hosting.stackcp.net' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'g[!$l?)q^}Tg^Zg-E{.^bE.G-r` fW1w>0%:M<!~D+pyK)5hg:SnUvj9=4.&$&0X' );
define( 'SECURE_AUTH_KEY',  '3eoE|nr:D@hHCR&>_VLM6(lW^+v/p=vnDut<cok:fsqV=LuwFEtIt#OywjG>UFIF' );
define( 'LOGGED_IN_KEY',    'hs2PnO81K>D7!@;K0_nhNn^eyKDt=*GN|Rsob-CE?!12PZ~{T/0xQd3,#XwLNX`9' );
define( 'NONCE_KEY',        '$.6B`VLCu; |jm(:u6(Fy+.Bdm<Ml96uz}X-z|&Pbv=[jOUjdxtl&g?_vX)>56k&' );
define( 'AUTH_SALT',        '4#qL`npzFNk1?NN-w8`tqp9H-o</t/Py#P&pU0-8/`svu2~2fq0j[K*>t{ICi]s=' );
define( 'SECURE_AUTH_SALT', '_=}<-RCIu2M-;C7+wXPtlh,pa,^yTUx]0j6I0*)2[!OE2q1a>|w52SEx)2I$ZgfI' );
define( 'LOGGED_IN_SALT',   'Dl3YB,$k!e{L9/{L)73@M2KGBW/2K1vf/G6A)C]v|!EvS?zZzpOv3Y;|5APLSTWf' );
define( 'NONCE_SALT',       'idPjW02$*gciw7gx>?e:<dr#yvk*K>9L4FrL5_7}MYDdI?!ZX2(uLWK6_7ay[8oh' );
define( 'ALLOW_UNFILTERED_UPLOADS', true);

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
